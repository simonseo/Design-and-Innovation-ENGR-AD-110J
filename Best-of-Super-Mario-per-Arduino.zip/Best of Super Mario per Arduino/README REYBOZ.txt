The "Tone" directory is a library.

You have to install it in your Sketch!

You can use this guide:

http://arduino.cc/en/Guide/Libraries